from flask import Blueprint, request, jsonify
from backend.database.models import db, Student, Attendance
from backend.utils.face_recognition import FaceRecognitionEngine
from datetime import datetime, date
import cv2, numpy as np

attendance_bp = Blueprint('attendance', __name__, url_prefix='/api/attendance')
engine = FaceRecognitionEngine(enrolled_dir='enrolled_faces')

# ── Mark attendance via uploaded / webcam frame ──────────────────────
@attendance_bp.route('/mark', methods=['POST'])
def mark_attendance():
    data = request.get_json()
    if not data.get('image_base64'):
        return jsonify({'error': 'image_base64 required'}), 400

    subject = data.get('subject', 'General')

    try:
        frame = engine.base64_to_image(data['image_base64'])
    except Exception as e:
        return jsonify({'error': f'Invalid image: {e}'}), 400

    students = Student.query.filter_by(is_active=True).all()
    if not students:
        return jsonify({'error': 'No enrolled students'}), 422

    recognition_results = engine.recognize_faces(frame, students)

    marked   = []
    unknown  = []
    today    = date.today()
    now      = datetime.utcnow()

    for r in recognition_results:
        if r['status'] == 'recognized':
            # Avoid double-marking same student on same day + subject
            already = Attendance.query.filter_by(
                student_id = r['student_id'],
                subject    = subject,
                date       = today
            ).first()
            if not already:
                rec = Attendance(
                    student_id = r['student_id'],
                    subject    = subject,
                    date       = today,
                    time_in    = now,
                    status     = 'Present',
                    confidence = r['confidence'],
                    marked_by  = 'system'
                )
                db.session.add(rec)
                marked.append(r)
            else:
                r['already_marked'] = True
                marked.append(r)
        else:
            unknown.append(r)

    db.session.commit()

    # Return annotated frame
    annotated = engine.annotate_frame(frame, recognition_results)
    annotated_b64 = engine.image_to_base64(annotated)

    return jsonify({
        'marked'        : marked,
        'unknown'       : unknown,
        'total_detected': len(recognition_results),
        'annotated_image': annotated_b64
    })

# ── Get attendance records ─────────────────────────────────────────────
@attendance_bp.route('/', methods=['GET'])
def get_attendance():
    subject   = request.args.get('subject')
    date_str  = request.args.get('date')
    student_q = request.args.get('student_id')

    query = Attendance.query
    if subject:
        query = query.filter_by(subject=subject)
    if date_str:
        try:
            d = date.fromisoformat(date_str)
            query = query.filter_by(date=d)
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400
    if student_q:
        query = query.filter_by(student_id=student_q)

    records = query.order_by(Attendance.time_in.desc()).all()
    return jsonify({'records': [r.to_dict() for r in records], 'total': len(records)})

# ── Today's summary ───────────────────────────────────────────────────
@attendance_bp.route('/today', methods=['GET'])
def today_summary():
    subject = request.args.get('subject', 'General')
    today   = date.today()
    records = Attendance.query.filter_by(subject=subject, date=today).all()
    total   = Student.query.filter_by(is_active=True).count()
    present = len(records)
    return jsonify({
        'date'   : today.isoformat(),
        'subject': subject,
        'present': present,
        'absent' : total - present,
        'total'  : total,
        'records': [r.to_dict() for r in records]
    })

# ── Student attendance report ─────────────────────────────────────────
@attendance_bp.route('/report/<string:student_roll>', methods=['GET'])
def student_report(student_roll):
    s = Student.query.filter_by(student_id=student_roll).first_or_404()
    records = Attendance.query.filter_by(student_id=s.id)\
                              .order_by(Attendance.date.desc()).all()
    total   = len(records)
    present = sum(1 for r in records if r.status == 'Present')
    pct     = round(present / total * 100, 1) if total else 0
    return jsonify({
        'student'          : s.to_dict(),
        'total_classes'    : total,
        'present'          : present,
        'attendance_pct'   : pct,
        'records'          : [r.to_dict() for r in records]
    })

# ── Manual override ───────────────────────────────────────────────────
@attendance_bp.route('/manual', methods=['POST'])
def manual_mark():
    data    = request.get_json()
    s_roll  = data.get('student_id')
    subject = data.get('subject', 'General')
    date_s  = data.get('date', date.today().isoformat())
    status  = data.get('status', 'Present')

    s = Student.query.filter_by(student_id=s_roll).first_or_404()

    existing = Attendance.query.filter_by(
        student_id = s.id,
        subject    = subject,
        date       = date.fromisoformat(date_s)
    ).first()

    if existing:
        existing.status    = status
        existing.marked_by = 'manual'
    else:
        rec = Attendance(
            student_id = s.id,
            subject    = subject,
            date       = date.fromisoformat(date_s),
            time_in    = datetime.utcnow(),
            status     = status,
            marked_by  = 'manual'
        )
        db.session.add(rec)

    db.session.commit()
    return jsonify({'message': f'Attendance {status} for {s.name}'})

@attendance_bp.route('/stats', methods=['GET'])
def stats():
    total_students  = Student.query.filter_by(is_active=True).count()
    total_records   = Attendance.query.count()
    today_count     = Attendance.query.filter_by(date=date.today()).count()
    return jsonify({
        'total_students' : total_students,
        'total_records'  : total_records,
        'today_present'  : today_count,
    })
