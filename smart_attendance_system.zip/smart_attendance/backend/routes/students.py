from flask import Blueprint, request, jsonify
from backend.database.models import db, Student
from backend.utils.face_recognition import FaceRecognitionEngine
import os, base64, numpy as np
from datetime import datetime

students_bp = Blueprint('students', __name__, url_prefix='/api/students')
engine = FaceRecognitionEngine(enrolled_dir='enrolled_faces')

ENROLLED_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'enrolled_faces')

@students_bp.route('/', methods=['GET'])
def get_students():
    students = Student.query.filter_by(is_active=True).all()
    return jsonify({'students': [s.to_dict() for s in students], 'total': len(students)})

@students_bp.route('/<int:sid>', methods=['GET'])
def get_student(sid):
    s = Student.query.get_or_404(sid)
    return jsonify(s.to_dict())

@students_bp.route('/enroll', methods=['POST'])
def enroll_student():
    data = request.get_json()
    required = ['student_id', 'name', 'image_base64']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'Missing field: {field}'}), 400

    # Check duplicate
    if Student.query.filter_by(student_id=data['student_id']).first():
        return jsonify({'error': 'Student ID already enrolled'}), 409

    # Decode image
    try:
        image = engine.base64_to_image(data['image_base64'])
    except Exception as e:
        return jsonify({'error': f'Invalid image: {e}'}), 400

    result = engine.enroll_student(data['student_id'], data['name'], image, save_dir=ENROLLED_DIR)
    if not result['success']:
        return jsonify({'error': result['message']}), 422

    student = Student(
        student_id      = data['student_id'],
        name            = data['name'],
        email           = data.get('email'),
        department      = data.get('department'),
        year            = data.get('year'),
        face_image_path = result['face_path'],
    )
    student.set_face_encoding(result['embedding'])
    db.session.add(student)
    db.session.commit()
    return jsonify({'message': 'Enrolled successfully', 'student': student.to_dict()}), 201

@students_bp.route('/<int:sid>', methods=['PUT'])
def update_student(sid):
    s = Student.query.get_or_404(sid)
    data = request.get_json()
    for field in ['name', 'email', 'department', 'year']:
        if field in data:
            setattr(s, field, data[field])
    # Re-enroll face if new image provided
    if data.get('image_base64'):
        try:
            image = engine.base64_to_image(data['image_base64'])
        except Exception as e:
            return jsonify({'error': f'Invalid image: {e}'}), 400
        result = engine.enroll_student(s.student_id, s.name, image, save_dir=ENROLLED_DIR)
        if result['success']:
            s.set_face_encoding(result['embedding'])
            s.face_image_path = result['face_path']
    db.session.commit()
    return jsonify({'message': 'Updated', 'student': s.to_dict()})

@students_bp.route('/<int:sid>', methods=['DELETE'])
def delete_student(sid):
    s = Student.query.get_or_404(sid)
    s.is_active = False
    db.session.commit()
    return jsonify({'message': 'Student deactivated'})

@students_bp.route('/face/<string:student_id>', methods=['GET'])
def get_face_image(student_id):
    s = Student.query.filter_by(student_id=student_id).first_or_404()
    if not s.face_image_path or not os.path.exists(s.face_image_path):
        return jsonify({'error': 'Face image not found'}), 404
    import cv2
    img = cv2.imread(s.face_image_path)
    b64 = engine.image_to_base64(img)
    return jsonify({'image_base64': b64})
