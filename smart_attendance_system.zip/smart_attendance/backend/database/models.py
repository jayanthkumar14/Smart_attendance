from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import json

db = SQLAlchemy()

class Student(db.Model):
    __tablename__ = 'students'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=True)
    department = db.Column(db.String(100), nullable=True)
    year = db.Column(db.String(10), nullable=True)
    face_encoding = db.Column(db.Text, nullable=True)   # JSON encoded face embedding
    face_image_path = db.Column(db.String(255), nullable=True)
    enrolled_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationship
    attendances = db.relationship('Attendance', backref='student', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'student_id': self.student_id,
            'name': self.name,
            'email': self.email,
            'department': self.department,
            'year': self.year,
            'enrolled_at': self.enrolled_at.isoformat(),
            'is_active': self.is_active,
            'face_image_path': self.face_image_path
        }

    def get_face_encoding(self):
        if self.face_encoding:
            return json.loads(self.face_encoding)
        return None

    def set_face_encoding(self, encoding):
        self.face_encoding = json.dumps(encoding)


class Attendance(db.Model):
    __tablename__ = 'attendance'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('students.id'), nullable=False)
    subject = db.Column(db.String(100), nullable=True, default='General')
    date = db.Column(db.Date, default=datetime.utcnow().date)
    time_in = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='Present')  # Present, Absent, Late
    confidence = db.Column(db.Float, nullable=True)
    marked_by = db.Column(db.String(50), default='system')  # system or manual

    def to_dict(self):
        return {
            'id': self.id,
            'student_id': self.student_id,
            'student_name': self.student.name if self.student else '',
            'student_roll': self.student.student_id if self.student else '',
            'subject': self.subject,
            'date': self.date.isoformat(),
            'time_in': self.time_in.isoformat(),
            'status': self.status,
            'confidence': round(self.confidence * 100, 1) if self.confidence else None,
            'marked_by': self.marked_by
        }


class Subject(db.Model):
    __tablename__ = 'subjects'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    code = db.Column(db.String(20), unique=True, nullable=False)
    department = db.Column(db.String(100), nullable=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'code': self.code,
            'department': self.department
        }
