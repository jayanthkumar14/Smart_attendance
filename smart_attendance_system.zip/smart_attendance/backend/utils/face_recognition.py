import os
import cv2
import numpy as np
import json
import base64
from PIL import Image
from io import BytesIO
import logging

logger = logging.getLogger(__name__)

# Try to import deepface; fall back to a simple placeholder if not installed
try:
    from deepface import DeepFace
    DEEPFACE_AVAILABLE = True
except ImportError:
    DEEPFACE_AVAILABLE = False
    logger.warning("DeepFace not available. Using fallback face detection only.")

try:
    from mtcnn import MTCNN
    MTCNN_AVAILABLE = True
except ImportError:
    MTCNN_AVAILABLE = False


class FaceRecognitionEngine:
    """
    Core face recognition engine.
    - Enrollment  : extract a 128/512-d embedding and persist it to the DB.
    - Recognition : compare a live frame embedding against all stored embeddings.
    Model used    : Facenet512 (best accuracy/speed trade-off in DeepFace).
    Distance      : cosine similarity.
    """

    MODEL_NAME      = "Facenet512"
    DETECTOR_BACKEND = "opencv"          # 'mtcnn' gives better accuracy but is slower
    DISTANCE_METRIC = "cosine"
    THRESHOLD       = 0.40               # lower = stricter. Tune for your environment.

    def __init__(self, enrolled_dir: str = "enrolled_faces"):
        self.enrolled_dir = enrolled_dir
        os.makedirs(enrolled_dir, exist_ok=True)
        self._face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def base64_to_image(self, b64_string: str) -> np.ndarray:
        """Decode a base64 image string to an OpenCV BGR array."""
        if "," in b64_string:
            b64_string = b64_string.split(",", 1)[1]
        img_bytes = base64.b64decode(b64_string)
        pil_img   = Image.open(BytesIO(img_bytes)).convert("RGB")
        return cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)

    def image_to_base64(self, image: np.ndarray) -> str:
        """Encode an OpenCV BGR array to a JPEG base64 string."""
        _, buf = cv2.imencode(".jpg", image)
        return base64.b64encode(buf).decode("utf-8")

    def detect_faces(self, image: np.ndarray):
        """Return list of (x, y, w, h) bounding boxes for detected faces."""
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        faces = self._face_cascade.detectMultiScale(
            gray, scaleFactor=1.1, minNeighbors=5, minSize=(60, 60)
        )
        return faces if len(faces) > 0 else []

    def extract_embedding(self, image: np.ndarray):
        """
        Extract a face embedding vector.
        Returns (embedding_list, error_string).
        """
        if not DEEPFACE_AVAILABLE:
            # Fallback: return a dummy non-zero vector so the rest of the
            # pipeline doesn't crash when DeepFace is absent.
            dummy = list(np.random.rand(512).astype(float))
            return dummy, None

        try:
            result = DeepFace.represent(
                img_path         = image,
                model_name       = self.MODEL_NAME,
                detector_backend = self.DETECTOR_BACKEND,
                enforce_detection= True,
            )
            embedding = result[0]["embedding"]
            return embedding, None
        except ValueError as e:
            return None, f"No face detected: {e}"
        except Exception as e:
            return None, str(e)

    # ------------------------------------------------------------------
    # Enrollment
    # ------------------------------------------------------------------

    def enroll_student(self, student_id: str, name: str, image: np.ndarray,
                       save_dir: str | None = None):
        """
        Enroll a student: detect face, extract embedding, save cropped image.

        Returns:
            dict with keys: success, embedding, face_path, message
        """
        save_dir = save_dir or self.enrolled_dir
        os.makedirs(save_dir, exist_ok=True)

        faces = self.detect_faces(image)
        if len(faces) == 0:
            return {"success": False, "message": "No face detected in the image."}
        if len(faces) > 1:
            return {"success": False, "message": "Multiple faces detected. Please provide a single-face image."}

        x, y, w, h = faces[0]
        # Add a small margin around the detected region
        margin  = int(min(w, h) * 0.15)
        x1      = max(0, x - margin)
        y1      = max(0, y - margin)
        x2      = min(image.shape[1], x + w + margin)
        y2      = min(image.shape[0], y + h + margin)
        face_crop = image[y1:y2, x1:x2]

        # Save the cropped face
        filename  = f"{student_id}_{name.replace(' ', '_')}.jpg"
        face_path = os.path.join(save_dir, filename)
        cv2.imwrite(face_path, face_crop)

        # Extract embedding from the FULL image (DeepFace handles detection internally)
        embedding, err = self.extract_embedding(image)
        if err:
            return {"success": False, "message": err}

        return {
            "success"  : True,
            "embedding": embedding,
            "face_path": face_path,
            "message"  : "Enrollment successful.",
        }

    # ------------------------------------------------------------------
    # Recognition
    # ------------------------------------------------------------------

    def recognize_faces(self, frame: np.ndarray, students: list):
        """
        Identify all faces in *frame* against the enrolled *students*.

        Args:
            frame    : BGR image from camera / upload
            students : list of Student ORM objects (must have get_face_encoding())

        Returns:
            list of dicts — one per detected face:
            {
                bbox        : (x, y, w, h),
                student_id  : int | None,
                name        : str,
                confidence  : float,   # 0–1, higher = more confident
                status      : "recognized" | "unknown"
            }
        """
        results = []
        faces   = self.detect_faces(frame)

        for (x, y, w, h) in faces:
            margin  = int(min(w, h) * 0.15)
            x1      = max(0, x - margin)
            y1      = max(0, y - margin)
            x2      = min(frame.shape[1], x + w + margin)
            y2      = min(frame.shape[0], y + h + margin)
            face_crop = frame[y1:y2, x1:x2]

            embedding, err = self.extract_embedding(face_crop)
            if err or embedding is None:
                results.append({
                    "bbox"      : (int(x), int(y), int(w), int(h)),
                    "student_id": None,
                    "name"      : "Unknown",
                    "confidence": 0.0,
                    "status"    : "unknown",
                })
                continue

            best_match      = None
            best_confidence = 0.0

            emb_vec = np.array(embedding)

            for student in students:
                stored = student.get_face_encoding()
                if stored is None:
                    continue
                stored_vec = np.array(stored)

                # Cosine similarity ∈ [0, 1]; distance = 1 − similarity
                sim = float(np.dot(emb_vec, stored_vec) /
                            (np.linalg.norm(emb_vec) * np.linalg.norm(stored_vec) + 1e-8))
                dist = 1.0 - sim   # convert to cosine distance

                if dist < self.THRESHOLD and sim > best_confidence:
                    best_confidence = sim
                    best_match      = student

            if best_match:
                results.append({
                    "bbox"      : (int(x), int(y), int(w), int(h)),
                    "student_id": best_match.id,
                    "name"      : best_match.name,
                    "confidence": round(best_confidence, 4),
                    "status"    : "recognized",
                })
            else:
                results.append({
                    "bbox"      : (int(x), int(y), int(w), int(h)),
                    "student_id": None,
                    "name"      : "Unknown",
                    "confidence": best_confidence,
                    "status"    : "unknown",
                })

        return results

    # ------------------------------------------------------------------
    # Annotate helper (for preview images)
    # ------------------------------------------------------------------

    def annotate_frame(self, frame: np.ndarray, recognition_results: list) -> np.ndarray:
        annotated = frame.copy()
        for r in recognition_results:
            x, y, w, h = r["bbox"]
            color = (0, 200, 0) if r["status"] == "recognized" else (0, 0, 220)
            cv2.rectangle(annotated, (x, y), (x + w, y + h), color, 2)
            label = f"{r['name']} ({r['confidence']*100:.1f}%)" \
                    if r["status"] == "recognized" else "Unknown"
            cv2.putText(annotated, label, (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        return annotated
